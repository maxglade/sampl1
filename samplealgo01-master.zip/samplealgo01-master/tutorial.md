# Step-by-step Tutorial

This content moved to https://docs.alpaca.markets/getting-started/sample-algo/