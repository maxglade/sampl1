from samplealgo import algo, btest

if __name__ == '__main__':
    #btest.simulate()
    algo.main()
